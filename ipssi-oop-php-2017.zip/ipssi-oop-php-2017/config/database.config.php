<?php

declare(strict_types=1);

return [
    'host' => 'demo',
    'name' => 'demo',
    'user' => 'root',
    'pass' => '',
    'port' => 3306,
];
