<?php

declare(strict_types=1);

namespace Application\Exception;

use LogicException;

final class InvalidControllerException extends LogicException
{
}
